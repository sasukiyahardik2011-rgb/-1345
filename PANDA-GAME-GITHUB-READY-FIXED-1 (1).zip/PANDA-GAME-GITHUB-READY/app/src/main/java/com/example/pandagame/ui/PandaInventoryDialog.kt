package com.example.pandagame.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.pandagame.model.BlockCategory
import com.example.pandagame.model.BlockType
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle

@Composable
fun PandaInventoryDialog(
    selectedBlock: BlockType,
    onSelectBlock: (BlockType) -> Unit,
    onDismiss: () -> Unit
) {
    val categories = listOf(
        BlockCategory.NATURE,
        BlockCategory.BUILDING,
        BlockCategory.DECORATION,
        BlockCategory.PANDA_SPECIAL
    )

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val activeCategory = categories[selectedTabIndex]

    val filteredBlocks = remember(activeCategory) {
        BlockType.selectableBlocks.filter { it.category == activeCategory }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(24.dp, RoundedCornerShape(28.dp))
                .testTag("panda_inventory_dialog"),
            shape = RoundedCornerShape(28.dp),
            color = GeoSurface,
            border = androidx.compose.foundation.BorderStroke(3.dp, GeoPrimaryDark)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🎒", fontSize = 22.sp, modifier = Modifier.padding(end = 8.dp))
                        Column {
                            Text(
                                text = "PANDA GAME",
                                color = GeoPrimaryDark,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "VOXEL BLOCK INVENTORY",
                                color = GeoPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(GeoAccentLight)
                            .border(1.5.dp, GeoPrimaryDark, RoundedCornerShape(10.dp))
                            .testTag("inventory_close_btn")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = GeoPrimaryDark)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Categories Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = GeoSurfaceSubtle,
                    contentColor = GeoPrimaryDark,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = GeoPrimary,
                            height = 3.dp
                        )
                    },
                    edgePadding = 0.dp
                ) {
                    categories.forEachIndexed { index, cat ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Text(
                                    text = cat.displayName,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTabIndex == index) GeoPrimaryDark else GeoPrimaryDark.copy(alpha = 0.6f)
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Block Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredBlocks, key = { it.id }) { block ->
                        val isSelected = (block == selectedBlock)
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    onSelectBlock(block)
                                    onDismiss()
                                }
                                .testTag("inventory_block_${block.name}"),
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) GeoAccentLight else GeoSurfaceSubtle,
                            border = androidx.compose.foundation.BorderStroke(
                                if (isSelected) 2.dp else 1.dp,
                                if (isSelected) GeoPrimary else GeoAccentSoft
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Color preview cube
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(block.topColor)
                                        .border(1.dp, Color.Black.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = block.displayName,
                                    color = GeoPrimaryDark,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Active block note pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GeoAccentLight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GeoAccentSoft)
                ) {
                    Text(
                        text = "Tap any block to build with it in PANDA GAME",
                        color = GeoPrimaryDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}
