package com.example.pandagame.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle
import com.example.ui.theme.PandaLanternAmber
import com.example.ui.theme.PandaSakuraPink

@Composable
fun NewWorldDialog(
    onDismiss: () -> Unit,
    onCreateWorld: (name: String, biome: String, seed: Long) -> Unit
) {
    var worldName by remember { mutableStateOf("My Panda Haven") }
    var selectedBiome by remember { mutableStateOf("Bamboo Forest") }
    var seedText by remember { mutableStateOf("${System.currentTimeMillis() % 100000}") }

    val biomes = listOf(
        Triple("Bamboo Forest", "🎋 Lush Bamboo Groves & Koi Streams", GeoPrimary),
        Triple("Sakura Valley", "🌸 Pink Cherry Blossoms & Zen Paths", PandaSakuraPink),
        Triple("Panda Sanctuary", "🏯 Ancient Pagoda Mountain Shrine", PandaLanternAmber),
        Triple("Zen Flatlands", "✨ Smooth Sandbox Building Platform", Color(0xFF0288D1))
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(24.dp, RoundedCornerShape(28.dp))
                .testTag("new_world_dialog"),
            shape = RoundedCornerShape(28.dp),
            color = GeoSurface,
            border = androidx.compose.foundation.BorderStroke(3.dp, GeoPrimaryDark)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PANDA GAME",
                            color = GeoPrimaryDark,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "CREATE NEW VOXEL WORLD",
                            color = GeoPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(GeoAccentLight)
                            .border(1.5.dp, GeoPrimaryDark, RoundedCornerShape(10.dp))
                            .testTag("new_world_close_btn")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = GeoPrimaryDark)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // World Name input
                OutlinedTextField(
                    value = worldName,
                    onValueChange = { worldName = it },
                    label = { Text("PANDA GAME World Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("world_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeoPrimary,
                        unfocusedBorderColor = GeoAccentSoft,
                        focusedTextColor = GeoPrimaryDark,
                        unfocusedTextColor = GeoPrimaryDark,
                        focusedLabelColor = GeoPrimary,
                        unfocusedLabelColor = GeoPrimaryDark.copy(alpha = 0.7f)
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Biome selector
                Text(
                    text = "Select Biome:",
                    color = GeoPrimaryDark,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    biomes.forEach { (name, desc, color) ->
                        val isSelected = (selectedBiome == name)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) GeoAccentLight else GeoSurfaceSubtle)
                                .border(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) GeoPrimaryDark else GeoAccentSoft,
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable { selectedBiome = name }
                                .padding(12.dp)
                                .testTag("biome_option_$name")
                        ) {
                            Column {
                                Text(
                                    text = name,
                                    color = if (isSelected) GeoPrimaryDark else GeoPrimaryDark.copy(alpha = 0.85f),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = desc,
                                    color = GeoPrimaryDark.copy(alpha = 0.7f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // World Seed
                OutlinedTextField(
                    value = seedText,
                    onValueChange = { seedText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("World Seed (Number)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("world_seed_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeoPrimary,
                        unfocusedBorderColor = GeoAccentSoft,
                        focusedTextColor = GeoPrimaryDark,
                        unfocusedTextColor = GeoPrimaryDark
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                PandaActionButton(
                    text = "Generate PANDA GAME World 🚀",
                    icon = Icons.Default.AutoAwesome,
                    onClick = {
                        val seed = seedText.toLongOrNull() ?: System.currentTimeMillis()
                        val finalName = if (worldName.isNotBlank()) worldName else "Panda Sanctuary"
                        onCreateWorld(finalName, selectedBiome, seed)
                    },
                    containerColor = GeoPrimary,
                    contentColor = Color.White,
                    cornerRadius = 24,
                    testTag = "generate_world_confirm_btn"
                )
            }
        }
    }
}
