package com.example.pandagame.model

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Vector3(
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f
) {
    operator fun plus(other: Vector3): Vector3 = Vector3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3): Vector3 = Vector3(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Float): Vector3 = Vector3(x * scalar, y * scalar, z * scalar)
    operator fun div(scalar: Float): Vector3 = if (scalar != 0f) Vector3(x / scalar, y / scalar, z / scalar) else this

    fun length(): Float = sqrt(x * x + y * y + z * z)
    fun lengthSquared(): Float = x * x + y * y + z * z

    fun normalized(): Vector3 {
        val len = length()
        return if (len > 0.0001f) Vector3(x / len, y / len, z / len) else Vector3(0f, 0f, 0f)
    }

    fun dot(other: Vector3): Float = x * other.x + y * other.y + z * other.z

    fun cross(other: Vector3): Vector3 = Vector3(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x
    )

    fun distanceTo(other: Vector3): Float = (this - other).length()

    companion object {
        val ZERO = Vector3(0f, 0f, 0f)
        val UP = Vector3(0f, 1f, 0f)
        val DOWN = Vector3(0f, -1f, 0f)
        val FORWARD = Vector3(0f, 0f, 1f)
        val BACKWARD = Vector3(0f, 0f, -1f)
        val RIGHT = Vector3(1f, 0f, 0f)
        val LEFT = Vector3(-1f, 0f, 0f)

        fun fromYawPitch(yawDeg: Float, pitchDeg: Float): Vector3 {
            val yawRad = Math.toRadians(yawDeg.toDouble())
            val pitchRad = Math.toRadians(pitchDeg.toDouble())
            val cosPitch = cos(pitchRad).toFloat()
            val sinPitch = sin(pitchRad).toFloat()
            val cosYaw = cos(yawRad).toFloat()
            val sinYaw = sin(yawRad).toFloat()

            return Vector3(
                x = sinYaw * cosPitch,
                y = -sinPitch,
                z = cosYaw * cosPitch
            ).normalized()
        }
    }
}

data class BlockPos(val x: Int, val y: Int, val z: Int) {
    operator fun plus(other: BlockPos) = BlockPos(x + other.x, y + other.y, z + other.z)
    operator fun plus(normal: BlockFace) = BlockPos(x + normal.dx, y + normal.dy, z + normal.dz)
}

enum class BlockFace(val dx: Int, val dy: Int, val dz: Int, val normal: Vector3) {
    TOP(0, 1, 0, Vector3(0f, 1f, 0f)),
    BOTTOM(0, -1, 0, Vector3(0f, -1f, 0f)),
    NORTH(0, 0, 1, Vector3(0f, 0f, 1f)),
    SOUTH(0, 0, -1, Vector3(0f, 0f, -1f)),
    EAST(1, 0, 0, Vector3(1f, 0f, 0f)),
    WEST(-1, 0, 0, Vector3(-1f, 0f, 0f));
}

data class RaycastResult(
    val hitBlockPos: BlockPos,
    val hitFace: BlockFace,
    val placeBlockPos: BlockPos,
    val hitDistance: Float
)
