package com.example.pandagame.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.pandagame.model.PlayerState
import com.example.pandagame.model.VoxelWorld
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle
import com.example.ui.theme.PandaLanternAmber
import com.example.ui.theme.PandaSakuraPink

@Composable
fun PauseMenuDialog(
    world: VoxelWorld,
    playerState: PlayerState,
    sensitivity: Float,
    onSensitivityChange: (Float) -> Unit,
    onResume: () -> Unit,
    onSaveWorld: () -> Unit,
    onToggleFlight: () -> Unit,
    onTogglePOV: () -> Unit,
    onOpenSaves: () -> Unit,
    onExitToMenu: () -> Unit
) {
    Dialog(onDismissRequest = onResume) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(24.dp, RoundedCornerShape(28.dp))
                .testTag("pause_menu_dialog"),
            shape = RoundedCornerShape(28.dp),
            color = GeoSurface,
            border = androidx.compose.foundation.BorderStroke(3.dp, GeoPrimaryDark)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with PANDA GAME in Geometric Balance Style
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🎋", fontSize = 22.sp, modifier = Modifier.padding(end = 8.dp))
                        Column {
                            Text(
                                text = "PANDA GAME",
                                color = GeoPrimaryDark,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "PAUSE & SANDBOX SETTINGS",
                                color = GeoPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = onResume,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(GeoAccentLight)
                            .border(1.5.dp, GeoPrimaryDark, RoundedCornerShape(10.dp))
                            .testTag("pause_dialog_close")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Resume", tint = GeoPrimaryDark)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // World stats pill
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = GeoAccentLight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GeoAccentSoft)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "World: ${world.worldName}",
                            color = GeoPrimaryDark,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Biome: ${world.biomeName}",
                            color = GeoPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Controls Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = GeoSurfaceSubtle,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, GeoAccentSoft)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // Flying mode toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Flight, contentDescription = null, tint = GeoPrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "Creative Flight", color = GeoPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Switch(
                                checked = playerState.isFlying,
                                onCheckedChange = { onToggleFlight() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = GeoPrimary
                                )
                            )
                        }

                        // 3rd Person POV
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Pets, contentDescription = null, tint = GeoPrimaryDark, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "Panda 3rd Person POV", color = GeoPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Switch(
                                checked = playerState.isThirdPerson,
                                onCheckedChange = { onTogglePOV() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = GeoPrimaryDark
                                )
                            )
                        }

                        // Sensitivity slider
                        Column(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Camera Sensitivity", color = GeoPrimaryDark, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text(text = "${(sensitivity * 100).toInt()}%", color = GeoPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = sensitivity,
                                onValueChange = onSensitivityChange,
                                valueRange = 0.1f..1.0f,
                                colors = SliderDefaults.colors(
                                    thumbColor = GeoPrimaryDark,
                                    activeTrackColor = GeoPrimary,
                                    inactiveTrackColor = GeoAccentLight
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Resume
                    PandaActionButton(
                        text = "RESUME PANDA GAME",
                        icon = Icons.Default.PlayArrow,
                        onClick = onResume,
                        containerColor = GeoPrimary,
                        contentColor = Color.White,
                        cornerRadius = 24,
                        testTag = "pause_resume_button"
                    )

                    // Save World
                    PandaActionButton(
                        text = "Save to PANDA GAME Saves",
                        icon = Icons.Default.Save,
                        onClick = onSaveWorld,
                        containerColor = GeoAccentLight,
                        contentColor = GeoPrimaryDark,
                        cornerRadius = 24,
                        testTag = "pause_save_world_button"
                    )

                    // Exit to Main Menu
                    PandaActionButton(
                        text = "Save & Exit to Menu",
                        icon = Icons.Default.ExitToApp,
                        onClick = onExitToMenu,
                        containerColor = Color(0xFFC62828),
                        contentColor = Color.White,
                        cornerRadius = 24,
                        testTag = "pause_exit_menu_button"
                    )
                }
            }
        }
    }
}
