package com.example.pandagame.model

data class PlayerState(
    var position: Vector3 = Vector3(16f, 14f, 16f),
    var yaw: Float = 0f,
    var pitch: Float = -15f,
    var velocity: Vector3 = Vector3.ZERO,
    var isFlying: Boolean = true,
    var isThirdPerson: Boolean = false,
    var selectedBlock: BlockType = BlockType.BAMBOO_STALK,
    var hotbar: List<BlockType> = listOf(
        BlockType.BAMBOO_STALK,
        BlockType.BAMBOO_LEAVES,
        BlockType.PANDA_LANTERN,
        BlockType.CHERRY_BLOSSOM,
        BlockType.PANDA_TOTEM,
        BlockType.BAMBOO_PLANKS,
        BlockType.PANDA_STONE,
        BlockType.ZEN_SAND
    ),
    var targetRaycast: RaycastResult? = null,
    var isGrounded: Boolean = false
) {
    fun getCameraLookVector(): Vector3 {
        return Vector3.fromYawPitch(yaw, pitch)
    }

    fun getCameraPosition(): Vector3 {
        return if (isThirdPerson) {
            val look = getCameraLookVector()
            // Pull back camera by 3.5 units
            position - (look * 3.5f) + Vector3(0f, 0.8f, 0f)
        } else {
            // Eye level
            position + Vector3(0f, 0.6f, 0f)
        }
    }
}
