package com.example.pandagame.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pandagame.engine.PandaVoxelRenderer
import com.example.pandagame.model.BlockType
import com.example.pandagame.model.PandaCompanion
import com.example.pandagame.model.PlayerState
import com.example.pandagame.model.VoxelWorld
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface

@Composable
fun InGameScreen(
    world: VoxelWorld,
    playerState: PlayerState,
    panda: PandaCompanion,
    timeOfDay: Float,
    renderDistance: Int,
    gameToast: String?,
    onMove: (Float, Float) -> Unit,
    onLook: (Float, Float) -> Unit,
    onJump: () -> Unit,
    onFlyDown: () -> Unit,
    onBreakBlock: () -> Unit,
    onPlaceBlock: () -> Unit,
    onTogglePOV: () -> Unit,
    onToggleFlight: () -> Unit,
    onToggleTime: () -> Unit,
    onFeedPanda: () -> Unit,
    onPause: () -> Unit,
    onSelectBlock: (BlockType) -> Unit,
    onOpenInventory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val voxelRenderer = remember { PandaVoxelRenderer() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("in_game_screen")
    ) {
        // 1. 3D Voxel Canvas Engine
        Canvas(modifier = Modifier.fillMaxSize()) {
            voxelRenderer.render(
                drawScope = this,
                world = world,
                player = playerState,
                panda = panda,
                timeOfDay = timeOfDay,
                renderDistance = renderDistance
            )
        }

        // 2. Interactive Touch Controls (Dpad, Drag look, HUD, Action buttons)
        PandaTouchControls(
            playerState = playerState,
            onMove = onMove,
            onLook = onLook,
            onJump = onJump,
            onFlyDown = onFlyDown,
            onBreakBlock = onBreakBlock,
            onPlaceBlock = onPlaceBlock,
            onTogglePOV = onTogglePOV,
            onToggleFlight = onToggleFlight,
            onToggleTime = onToggleTime,
            onFeedPanda = onFeedPanda,
            onPause = onPause,
            modifier = Modifier.fillMaxSize()
        )

        // 3. Bottom Hotbar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
        ) {
            PandaHotbar(
                hotbar = playerState.hotbar,
                selectedBlock = playerState.selectedBlock,
                onSelectBlock = onSelectBlock,
                onOpenInventory = onOpenInventory
            )
        }

        // 4. Toast notification popup
        AnimatedVisibility(
            visible = gameToast != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 56.dp)
        ) {
            if (gameToast != null) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = GeoSurface,
                    border = androidx.compose.foundation.BorderStroke(2.dp, GeoPrimaryDark),
                    modifier = Modifier.shadow(8.dp, RoundedCornerShape(20.dp))
                ) {
                    Text(
                        text = gameToast,
                        color = GeoPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 9.dp)
                    )
                }
            }
        }
    }
}
