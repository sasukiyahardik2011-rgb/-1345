package com.example.pandagame.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pandagame.model.BlockType
import com.example.pandagame.model.PlayerState
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentMid
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSecondary
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle
import com.example.ui.theme.PandaBlack
import com.example.ui.theme.PandaEmerald
import com.example.ui.theme.PandaLanternAmber
import com.example.ui.theme.PandaMint
import com.example.ui.theme.PandaSakuraPink

@Composable
fun PandaGameLogoHeader(
    modifier: Modifier = Modifier,
    subtitle: String = "3D Voxel Sandbox Adventure",
    showPandaEars: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "panda_logo_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .scale(scale),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Geometric Balance Top Block Tri-Square Accent
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(GeoPrimary)
            )
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(GeoPrimaryDark)
            )
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(GeoPrimary)
            )
        }

        if (showPandaEars) {
            // Cute Geometric Panda Ears
            Row(
                modifier = Modifier.width(170.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(GeoPrimaryDark)
                        .border(3.dp, GeoPrimary, CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(GeoPrimaryDark)
                        .border(3.dp, GeoPrimary, CircleShape)
                )
            }
        }

        // Main Geometric PANDA GAME Badge
        Surface(
            modifier = Modifier
                .padding(top = if (showPandaEars) (-8).dp else 0.dp)
                .shadow(10.dp, RoundedCornerShape(24.dp)),
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = BorderStroke(3.dp, GeoPrimaryDark)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "🎋",
                        fontSize = 22.sp,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text(
                        text = "PANDA ",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = GeoPrimaryDark,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "GAME",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = GeoPrimary,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "🐾",
                        fontSize = 22.sp,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }

                if (subtitle.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GeoAccentLight,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = subtitle.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = GeoPrimaryDark,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GeometricPandaEmblem(
    modifier: Modifier = Modifier,
    caption: String = "Build your bamboo world, block by block."
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(28.dp)),
        shape = RoundedCornerShape(28.dp),
        color = Color.White,
        border = BorderStroke(3.dp, GeoPrimaryDark)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Cute Geometric Panda Face Grid Card
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(GeoSurfaceSubtle)
                    .border(2.dp, GeoAccentSoft, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // Ears
                    Row(
                        modifier = Modifier.width(72.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(GeoPrimaryDark)
                        )
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(GeoPrimaryDark)
                        )
                    }
                    // Head Box
                    Surface(
                        modifier = Modifier
                            .size(76.dp, 56.dp)
                            .padding(top = 2.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White,
                        border = BorderStroke(2.dp, GeoPrimaryDark)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            // Eyes
                            Row(
                                modifier = Modifier.width(48.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(GeoPrimaryDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(4.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(GeoPrimaryDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(4.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                }
                            }
                            // Nose & Smile
                            Box(
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .size(8.dp, 6.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(GeoPrimaryDark)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Caption
            Text(
                text = caption,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = GeoPrimaryDark,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Indicator Dots (Geometric Balance Motif)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(24.dp, 6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(GeoPrimary)
                )
                Box(
                    modifier = Modifier
                        .size(8.dp, 6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(GeoAccentLight)
                )
                Box(
                    modifier = Modifier
                        .size(8.dp, 6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(GeoAccentLight)
                )
            }
        }
    }
}

@Composable
fun PandaActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    containerColor: Color = GeoPrimary,
    contentColor: Color = Color.White,
    cornerRadius: Int = 28,
    testTag: String = "panda_action_button"
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(cornerRadius.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
            }
            Text(
                text = text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun PandaCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = GeoSurface,
        border = BorderStroke(2.dp, GeoPrimaryDark),
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            content()
        }
    }
}

@Composable
fun PandaHotbar(
    hotbar: List<BlockType>,
    selectedBlock: BlockType,
    onSelectBlock: (BlockType) -> Unit,
    onOpenInventory: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .shadow(12.dp, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        color = GeoSurface,
        border = BorderStroke(2.5.dp, GeoPrimaryDark)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            hotbar.forEach { block ->
                val isSelected = (block == selectedBlock)
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) GeoAccentLight else GeoSurfaceSubtle)
                        .border(
                            if (isSelected) 2.5.dp else 1.dp,
                            if (isSelected) GeoPrimary else GeoAccentSoft,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { onSelectBlock(block) }
                        .testTag("hotbar_slot_${block.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    // Block color swatch preview
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(block.topColor)
                            .border(1.dp, Color.Black.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                    )
                }
            }

            // More / Bag button
            Box(
                modifier = Modifier
                    .padding(start = 4.dp)
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(GeoAccentLight)
                    .border(1.5.dp, GeoPrimaryDark, RoundedCornerShape(12.dp))
                    .clickable { onOpenInventory() }
                    .testTag("open_inventory_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🎒", fontSize = 18.sp)
            }
        }
    }
}

@Composable
fun PandaTouchControls(
    playerState: PlayerState,
    onMove: (Float, Float) -> Unit,
    onLook: (Float, Float) -> Unit,
    onJump: () -> Unit,
    onFlyDown: () -> Unit,
    onBreakBlock: () -> Unit,
    onPlaceBlock: () -> Unit,
    onTogglePOV: () -> Unit,
    onToggleFlight: () -> Unit,
    onToggleTime: () -> Unit,
    onFeedPanda: () -> Unit,
    onPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {

        // 1. Right half touch-look area for smooth 3D camera rotation
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 140.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onLook(dragAmount.x * 0.7f, dragAmount.y * 0.7f)
                    }
                }
        )

        // 2. Top HUD Bar (Pause, Day/Night, Flight, POV, Panda status)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // PANDA GAME HUD badge
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = GeoSurface,
                border = BorderStroke(2.dp, GeoPrimaryDark),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🎋 PANDA GAME",
                        color = GeoPrimaryDark,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "X:${playerState.position.x.toInt()} Y:${playerState.position.y.toInt()} Z:${playerState.position.z.toInt()}",
                        color = GeoPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Quick Toggle Controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Day / Night
                IconButton(
                    onClick = onToggleTime,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(GeoSurface)
                        .border(1.5.dp, GeoPrimaryDark, RoundedCornerShape(12.dp))
                        .testTag("toggle_time_button")
                ) {
                    Icon(Icons.Default.LightMode, contentDescription = "Time of Day", tint = GeoPrimaryDark, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))

                // Fly mode toggle
                IconButton(
                    onClick = onToggleFlight,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (playerState.isFlying) GeoPrimary else GeoSurface)
                        .border(1.5.dp, GeoPrimaryDark, RoundedCornerShape(12.dp))
                        .testTag("toggle_flight_button")
                ) {
                    Icon(
                        Icons.Default.Flight,
                        contentDescription = "Toggle Flight",
                        tint = if (playerState.isFlying) Color.White else GeoPrimaryDark,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))

                // 3rd Person Panda POV
                IconButton(
                    onClick = onTogglePOV,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (playerState.isThirdPerson) GeoAccentSoft else GeoSurface)
                        .border(1.5.dp, GeoPrimaryDark, RoundedCornerShape(12.dp))
                        .testTag("toggle_pov_button")
                ) {
                    Icon(
                        Icons.Default.Pets,
                        contentDescription = "Panda POV",
                        tint = GeoPrimaryDark,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))

                // Pause Button
                IconButton(
                    onClick = onPause,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFC62828))
                        .border(1.5.dp, Color(0xFF880E4F), RoundedCornerShape(12.dp))
                        .testTag("pause_game_button")
                ) {
                    Icon(Icons.Default.Pause, contentDescription = "Pause PANDA GAME", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }

        // 3. Movement D-PAD (Bottom Left)
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, bottom = 74.dp)
                .size(130.dp)
        ) {
            // Forward (Up)
            DpadButton(
                modifier = Modifier.align(Alignment.TopCenter),
                icon = Icons.Default.KeyboardArrowUp,
                onClick = { onMove(0f, 1f) },
                testTag = "dpad_up"
            )
            // Backward (Down)
            DpadButton(
                modifier = Modifier.align(Alignment.BottomCenter),
                icon = Icons.Default.KeyboardArrowDown,
                onClick = { onMove(0f, -1f) },
                testTag = "dpad_down"
            )
            // Strafe Left
            DpadButton(
                modifier = Modifier.align(Alignment.CenterStart),
                icon = Icons.Default.KeyboardArrowLeft,
                onClick = { onMove(-1f, 0f) },
                testTag = "dpad_left"
            )
            // Strafe Right
            DpadButton(
                modifier = Modifier.align(Alignment.CenterEnd),
                icon = Icons.Default.KeyboardArrowRight,
                onClick = { onMove(1f, 0f) },
                testTag = "dpad_right"
            )
            // Feed Panda Center
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(GeoPrimary)
                    .border(1.5.dp, GeoPrimaryDark, CircleShape)
                    .clickable { onFeedPanda() }
                    .testTag("dpad_feed_center"),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🎋", fontSize = 16.sp)
            }
        }

        // 4. Action Buttons: Place, Break, Jump, Fly Down (Bottom Right)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 74.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Break Block Button
                ActionButtonCircle(
                    text = "BREAK",
                    color = Color(0xFFD32F2F),
                    icon = Icons.Default.Remove,
                    onClick = onBreakBlock,
                    testTag = "action_break_block"
                )

                // Place Block Button
                ActionButtonCircle(
                    text = "BUILD",
                    color = GeoPrimary,
                    icon = Icons.Default.Add,
                    onClick = onPlaceBlock,
                    testTag = "action_place_block"
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (playerState.isFlying) {
                    // Fly Down
                    ActionButtonCircle(
                        text = "DOWN",
                        color = GeoPrimaryDark,
                        icon = Icons.Default.ArrowDownward,
                        onClick = onFlyDown,
                        testTag = "action_fly_down"
                    )
                }

                // Jump / Fly Up
                ActionButtonCircle(
                    text = if (playerState.isFlying) "UP" else "JUMP",
                    color = GeoPrimary,
                    icon = Icons.Default.ArrowUpward,
                    onClick = onJump,
                    testTag = "action_jump"
                )
            }
        }
    }
}

@Composable
private fun DpadButton(
    modifier: Modifier,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = modifier
            .size(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(GeoSurface)
            .border(2.dp, GeoPrimaryDark, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = GeoPrimaryDark, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun ActionButtonCircle(
    text: String,
    color: Color,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .size(54.dp)
            .shadow(6.dp, CircleShape)
            .testTag(testTag),
        shape = CircleShape,
        color = color,
        border = BorderStroke(2.dp, GeoPrimaryDark),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = text, tint = Color.White, modifier = Modifier.size(20.dp))
            Text(
                text = text,
                color = Color.White,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
