package com.example.pandagame.model

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

enum class PandaMood(val statusText: String, val emoji: String) {
    HAPPY("Chewing Bamboo", "🎋"),
    CURIOUS("Exploring Voxel World", "🐾"),
    RESTING("Zen Meditation", "🌸"),
    PLAYFUL("Rolling Around", "✨")
}

data class PandaCompanion(
    var position: Vector3 = Vector3(18f, 12f, 18f),
    var yaw: Float = 45f,
    var targetPos: Vector3 = Vector3(18f, 12f, 18f),
    var mood: PandaMood = PandaMood.HAPPY,
    var animTime: Float = 0f,
    var isEating: Boolean = true,
    var heartsRemaining: Int = 0
) {
    fun update(deltaTime: Float, playerPos: Vector3, world: VoxelWorld) {
        animTime += deltaTime

        val distToPlayer = position.distanceTo(playerPos)
        if (distToPlayer > 8f) {
            // Teleport near player if too far
            position = playerPos + Vector3(2f, 0f, 2f)
            targetPos = position
        } else if (distToPlayer > 3f) {
            // Walk towards player
            val dir = (playerPos - position).normalized()
            val moveSpeed = 1.8f * deltaTime
            position = position + (dir * moveSpeed)
            val dx = playerPos.x - position.x
            val dz = playerPos.z - position.z
            yaw = Math.toDegrees(atan2(dx.toDouble(), dz.toDouble())).toFloat()
            mood = PandaMood.CURIOUS
            isEating = false
        } else {
            // Idle and snack on bamboo
            if ((animTime.toInt() / 4) % 2 == 0) {
                mood = PandaMood.HAPPY
                isEating = true
            } else {
                mood = PandaMood.RESTING
                isEating = false
            }
        }

        // Adjust Y to terrain height
        val bx = position.x.toInt()
        val bz = position.z.toInt()
        for (y in (world.sizeY - 1) downTo 0) {
            val b = world.getBlock(bx, y, bz)
            if (b != BlockType.AIR && b != BlockType.CRYSTAL_WATER) {
                position = Vector3(position.x, (y + 1).toFloat(), position.z)
                break
            }
        }
    }
}
