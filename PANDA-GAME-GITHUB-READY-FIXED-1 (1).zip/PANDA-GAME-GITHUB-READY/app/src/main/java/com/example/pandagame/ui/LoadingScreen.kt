package com.example.pandagame.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle

@Composable
fun LoadingScreen(
    message: String,
    progress: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "panda_loading")
    val bounce by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bounce"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GeoBackground)
            .testTag("loading_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // PANDA GAME Logo Header
            PandaGameLogoHeader(
                subtitle = "Generating Voxel World...",
                showPandaEars = true
            )

            Spacer(modifier = Modifier.height(30.dp))

            // Geometric Panda Card
            Surface(
                modifier = Modifier
                    .size(120.dp)
                    .scale(bounce)
                    .shadow(10.dp, RoundedCornerShape(26.dp)),
                shape = RoundedCornerShape(26.dp),
                color = GeoSurface,
                border = androidx.compose.foundation.BorderStroke(3.dp, GeoPrimaryDark)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(text = "🐼", fontSize = 46.sp)
                    Text(text = "🎋", fontSize = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Geometric Progress Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(16.dp),
                shape = RoundedCornerShape(8.dp),
                color = GeoAccentLight,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, GeoPrimaryDark)
            ) {
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxSize(),
                    color = GeoPrimary,
                    trackColor = GeoAccentLight,
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Status message pill
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = GeoAccentLight,
                border = androidx.compose.foundation.BorderStroke(1.dp, GeoAccentSoft)
            ) {
                Text(
                    text = message,
                    color = GeoPrimaryDark,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Geometric Indicator Dots
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(24.dp, 6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(GeoPrimary)
                )
                Box(
                    modifier = Modifier
                        .size(8.dp, 6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(GeoAccentSoft)
                )
                Box(
                    modifier = Modifier
                        .size(8.dp, 6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(GeoAccentSoft)
                )
            }
        }
    }
}
