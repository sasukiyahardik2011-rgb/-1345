package com.example.pandagame.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle

@Composable
fun MainMenuScreen(
    onPlayDefault: () -> Unit,
    onCreateNewWorld: () -> Unit,
    onOpenSaves: () -> Unit,
    onOpenGuide: () -> Unit,
    onOpenSettings: () -> Unit,
    onBackToTitle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GeoBackground)
            .testTag("main_menu_screen")
    ) {
        // Decorative background image subtle pattern
        Image(
            painter = painterResource(id = R.drawable.img_panda_banner),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.08f
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Navigation Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackToTitle,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(2.dp, GeoPrimaryDark, RoundedCornerShape(14.dp))
                        .testTag("menu_back_to_title_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back to Title", tint = GeoPrimaryDark)
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GeoAccentLight,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, GeoPrimaryDark)
                ) {
                    Text(
                        text = "MAIN MENU",
                        color = GeoPrimaryDark,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Prominent Geometric PANDA GAME Logo Header
            PandaGameLogoHeader(
                subtitle = "Main Menu & Sandbox Portal",
                showPandaEars = true
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Menu Options Container (Geometric Balance Card)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(10.dp, RoundedCornerShape(26.dp)),
                shape = RoundedCornerShape(26.dp),
                color = GeoSurface,
                border = androidx.compose.foundation.BorderStroke(2.5.dp, GeoPrimaryDark)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Quick Play (Primary Action - #2E7D32, rounded-3xl / 28dp)
                    PandaActionButton(
                        text = "PLAY PANDA GAME",
                        icon = Icons.Default.PlayArrow,
                        onClick = onPlayDefault,
                        containerColor = GeoPrimary,
                        contentColor = Color.White,
                        cornerRadius = 28,
                        testTag = "menu_play_default_button"
                    )

                    // Create New World
                    PandaActionButton(
                        text = "Create New Voxel World",
                        icon = Icons.Default.Add,
                        onClick = onCreateNewWorld,
                        containerColor = GeoAccentLight,
                        contentColor = GeoPrimaryDark,
                        cornerRadius = 24,
                        testTag = "menu_create_new_button"
                    )

                    // Saved Worlds
                    PandaActionButton(
                        text = "PANDA GAME Saves",
                        icon = Icons.Default.FolderOpen,
                        onClick = onOpenSaves,
                        containerColor = GeoAccentLight,
                        contentColor = GeoPrimaryDark,
                        cornerRadius = 24,
                        testTag = "menu_saved_worlds_button"
                    )

                    // Panda Guide
                    PandaActionButton(
                        text = "Panda Handbook & Guide",
                        icon = Icons.Default.Book,
                        onClick = onOpenGuide,
                        containerColor = GeoSurfaceSubtle,
                        contentColor = GeoPrimaryDark,
                        cornerRadius = 24,
                        testTag = "menu_guide_button"
                    )

                    // Settings
                    PandaActionButton(
                        text = "Sandbox Settings",
                        icon = Icons.Default.Settings,
                        onClick = onOpenSettings,
                        containerColor = GeoSurfaceSubtle,
                        contentColor = GeoPrimaryDark,
                        cornerRadius = 24,
                        testTag = "menu_settings_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Geometric Panda Info Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = GeoAccentLight,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, GeoAccentSoft)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🐼", fontSize = 28.sp, modifier = Modifier.padding(end = 12.dp))
                    Column {
                        Text(
                            text = "PANDA GAME Tip:",
                            color = GeoPrimaryDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Switch to 3rd-person mode to explore as a cute blocky panda cub!",
                            color = GeoPrimaryDark.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
