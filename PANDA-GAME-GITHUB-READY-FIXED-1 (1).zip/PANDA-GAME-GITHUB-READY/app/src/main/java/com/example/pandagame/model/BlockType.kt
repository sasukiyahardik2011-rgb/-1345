package com.example.pandagame.model

import androidx.compose.ui.graphics.Color

enum class BlockCategory(val displayName: String) {
    NATURE("Nature & Flora"),
    BUILDING("Building Blocks"),
    DECORATION("Zen Deco"),
    PANDA_SPECIAL("Panda Specials")
}

enum class BlockType(
    val id: Byte,
    val displayName: String,
    val category: BlockCategory,
    val topColor: Color,
    val sideColor: Color,
    val bottomColor: Color,
    val isTransparent: Boolean = false,
    val isLightEmitter: Boolean = false,
    val soundPitch: Float = 1.0f
) {
    AIR(
        id = 0,
        displayName = "Air",
        category = BlockCategory.NATURE,
        topColor = Color.Transparent,
        sideColor = Color.Transparent,
        bottomColor = Color.Transparent,
        isTransparent = true
    ),
    PANDA_GRASS(
        id = 1,
        displayName = "Panda Grass",
        category = BlockCategory.NATURE,
        topColor = Color(0xFF43A047),
        sideColor = Color(0xFF2E7D32),
        bottomColor = Color(0xFF3E2723),
        soundPitch = 1.2f
    ),
    PANDA_SOIL(
        id = 2,
        displayName = "Rich Soil",
        category = BlockCategory.NATURE,
        topColor = Color(0xFF4E342E),
        sideColor = Color(0xFF3E2723),
        bottomColor = Color(0xFF271916),
        soundPitch = 0.9f
    ),
    BAMBOO_STALK(
        id = 3,
        displayName = "Bamboo Stalk",
        category = BlockCategory.NATURE,
        topColor = Color(0xFF66BB6A),
        sideColor = Color(0xFF388E3C),
        bottomColor = Color(0xFF2E7D32),
        soundPitch = 1.5f
    ),
    BAMBOO_LEAVES(
        id = 4,
        displayName = "Bamboo Canopy",
        category = BlockCategory.NATURE,
        topColor = Color(0xFF81C784),
        sideColor = Color(0xFF4CAF50),
        bottomColor = Color(0xFF2E7D32),
        isTransparent = true,
        soundPitch = 1.4f
    ),
    CHERRY_BLOSSOM(
        id = 5,
        displayName = "Sakura Blossom",
        category = BlockCategory.NATURE,
        topColor = Color(0xFFFF80AB),
        sideColor = Color(0xFFF48FB1),
        bottomColor = Color(0xFFEC407A),
        isTransparent = true,
        soundPitch = 1.6f
    ),
    CHERRY_WOOD(
        id = 6,
        displayName = "Sakura Wood",
        category = BlockCategory.BUILDING,
        topColor = Color(0xFF8D6E63),
        sideColor = Color(0xFF6D4C41),
        bottomColor = Color(0xFF4E342E),
        soundPitch = 1.0f
    ),
    BAMBOO_PLANKS(
        id = 7,
        displayName = "Bamboo Planks",
        category = BlockCategory.BUILDING,
        topColor = Color(0xFFC5E1A5),
        sideColor = Color(0xFFAED581),
        bottomColor = Color(0xFF9CCC65),
        soundPitch = 1.1f
    ),
    PANDA_STONE(
        id = 8,
        displayName = "Panda Slate",
        category = BlockCategory.BUILDING,
        topColor = Color(0xFF546E7A),
        sideColor = Color(0xFF455A64),
        bottomColor = Color(0xFF37474F),
        soundPitch = 0.8f
    ),
    PANDA_COBBLE(
        id = 9,
        displayName = "Panda Cobble",
        category = BlockCategory.BUILDING,
        topColor = Color(0xFF78909C),
        sideColor = Color(0xFF607D8B),
        bottomColor = Color(0xFF455A64),
        soundPitch = 0.85f
    ),
    MOSS_BRICK(
        id = 10,
        displayName = "Mossy Temple Stone",
        category = BlockCategory.BUILDING,
        topColor = Color(0xFF689F38),
        sideColor = Color(0xFF558B2F),
        bottomColor = Color(0xFF33691E),
        soundPitch = 0.8f
    ),
    PANDA_LANTERN(
        id = 11,
        displayName = "Panda Lantern",
        category = BlockCategory.DECORATION,
        topColor = Color(0xFFFFD54F),
        sideColor = Color(0xFFFFB300),
        bottomColor = Color(0xFFFFA000),
        isLightEmitter = true,
        soundPitch = 1.8f
    ),
    ZEN_SAND(
        id = 12,
        displayName = "Zen Garden Sand",
        category = BlockCategory.DECORATION,
        topColor = Color(0xFFFFECB3),
        sideColor = Color(0xFFFFE082),
        bottomColor = Color(0xFFFFD54F),
        soundPitch = 1.3f
    ),
    CRYSTAL_WATER(
        id = 13,
        displayName = "Koi Stream Water",
        category = BlockCategory.NATURE,
        topColor = Color(0xCC29B6F6),
        sideColor = Color(0xCC0288D1),
        bottomColor = Color(0xCC01579B),
        isTransparent = true,
        soundPitch = 1.7f
    ),
    PANDA_FUR_WHITE(
        id = 14,
        displayName = "Panda White Fur",
        category = BlockCategory.PANDA_SPECIAL,
        topColor = Color(0xFFFAFAFA),
        sideColor = Color(0xFFEEEEEE),
        bottomColor = Color(0xFFE0E0E0),
        soundPitch = 1.2f
    ),
    PANDA_FUR_BLACK(
        id = 15,
        displayName = "Panda Black Fur",
        category = BlockCategory.PANDA_SPECIAL,
        topColor = Color(0xFF263238),
        sideColor = Color(0xFF212121),
        bottomColor = Color(0xFF141414),
        soundPitch = 1.1f
    ),
    PANDA_TOTEM(
        id = 16,
        displayName = "Carved Panda Totem",
        category = BlockCategory.PANDA_SPECIAL,
        topColor = Color(0xFFB0BEC5),
        sideColor = Color(0xFF78909C),
        bottomColor = Color(0xFF546E7A),
        soundPitch = 1.0f
    ),
    GOLDEN_BAMBOO(
        id = 17,
        displayName = "Golden Bamboo",
        category = BlockCategory.PANDA_SPECIAL,
        topColor = Color(0xFFFFEE58),
        sideColor = Color(0xFFFDD835),
        bottomColor = Color(0xFFFBC02D),
        isLightEmitter = true,
        soundPitch = 1.9f
    ),
    GLASS_BLOCK(
        id = 18,
        displayName = "Panda Crystal Glass",
        category = BlockCategory.BUILDING,
        topColor = Color(0x99B2EBF2),
        sideColor = Color(0x8880DEEA),
        bottomColor = Color(0x994DD0E1),
        isTransparent = true,
        soundPitch = 1.6f
    );

    companion object {
        private val idMap = entries.associateBy { it.id }
        fun fromId(id: Byte): BlockType = idMap[id] ?: AIR

        val selectableBlocks = entries.filter { it != AIR }
    }
}
