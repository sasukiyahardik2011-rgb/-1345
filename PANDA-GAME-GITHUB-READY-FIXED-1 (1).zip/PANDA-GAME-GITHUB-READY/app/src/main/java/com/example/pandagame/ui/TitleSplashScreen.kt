package com.example.pandagame.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle

@Composable
fun TitleSplashScreen(
    onStartGame: () -> Unit,
    onOpenMainMenu: () -> Unit,
    onOpenSaves: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GeoBackground)
            .testTag("title_splash_screen")
    ) {
        // Subtle ambient bamboo backdrop texture
        Image(
            painter = painterResource(id = R.drawable.img_panda_banner),
            contentDescription = "PANDA GAME 3D Voxel World",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.12f
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Signature Geometric PANDA GAME Header
            PandaGameLogoHeader(
                subtitle = "3D Voxel Sandbox Adventure",
                showPandaEars = true
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Center Geometric Panda Emblem Card (Signature Geometric Balance Component)
            GeometricPandaEmblem(
                caption = "Build your bamboo world, block by block.",
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons Section
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Primary Action Button (rounded-3xl / 28dp, #2E7D32)
                PandaActionButton(
                    text = "ENTER PANDA GAME",
                    icon = Icons.Default.PlayArrow,
                    onClick = onStartGame,
                    containerColor = GeoPrimary,
                    contentColor = Color.White,
                    cornerRadius = 28,
                    testTag = "enter_panda_game_button"
                )

                // Secondary 2-Column Button Row (#C8E6C9, #1B5E20 text, rounded-2xl / 24dp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PandaActionButton(
                        text = "Menu",
                        icon = Icons.Default.Settings,
                        onClick = onOpenMainMenu,
                        containerColor = GeoAccentLight,
                        contentColor = GeoPrimaryDark,
                        cornerRadius = 24,
                        modifier = Modifier.weight(1f),
                        testTag = "open_main_menu_button"
                    )

                    PandaActionButton(
                        text = "Saves",
                        icon = Icons.Default.FolderOpen,
                        onClick = onOpenSaves,
                        containerColor = GeoAccentLight,
                        contentColor = GeoPrimaryDark,
                        cornerRadius = 24,
                        modifier = Modifier.weight(1f),
                        testTag = "title_saved_worlds_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Geometric Footer Pill
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = GeoAccentLight.copy(alpha = 0.7f),
                border = androidx.compose.foundation.BorderStroke(1.dp, GeoAccentSoft)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🐾", fontSize = 12.sp, modifier = Modifier.padding(end = 6.dp))
                    Text(
                        text = "PANDA GAME v1.0.4 • Offline 3D Voxel Sandbox",
                        color = GeoPrimaryDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}
